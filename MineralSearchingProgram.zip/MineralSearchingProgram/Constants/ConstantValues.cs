﻿namespace MineralSearchingProgram.Constants;

public static class ConstantValues
{
	public const int MinMapSize = 0;
	public const int MaxMapSize = 100;
}

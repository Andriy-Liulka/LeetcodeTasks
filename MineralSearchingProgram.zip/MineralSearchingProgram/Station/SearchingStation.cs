﻿using MineralSearchingProgram.Calculation;
using MineralSearchingProgram.Constants;

namespace MineralSearchingProgram.Station;

internal class SearchingStation
{
    public int X { get; set; }
    public int Y { get; set; }
    public int Z { get; set; }
    public IList<Coordinate> SurfaceCoordinates { get; set; }
    private double Radius { get; set; }

	public SearchingStation(int x, int y, int z)
    {
        X = x;
        Y = y;
        Z = z;
		SurfaceCoordinates = new List<Coordinate>();
	}

	public double GetDistanceToMeteor(Coordinate meteorCoordinate)
	{
		var distance = Calculator.CalculateDistance(meteorCoordinate, new Coordinate(X, Y, Z));
		Radius = distance;
		return distance;
	}
	public void CalculateSurfaceCoordinates()
    {
		for (int x = 0; x <= ConstantValues.MaxMapSize; x++)
        {
			for (int y = 0; y <= ConstantValues.MaxMapSize; y++)
			{
				for (int z = 0; z <= ConstantValues.MaxMapSize; z++)
				{
					var calculationDistanceResult = Calculator.CalculateDistance(new Coordinate(this.X, this.Y, this.Z), new Coordinate(x, y, z));
					if (calculationDistanceResult == Radius)
					{
						SurfaceCoordinates.Add(new Coordinate(x, y, z));
					}
				}
			}
		}
    }
}

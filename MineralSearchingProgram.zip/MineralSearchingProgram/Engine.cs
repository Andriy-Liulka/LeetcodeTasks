﻿using MineralSearchingProgram.Calculation;
using MineralSearchingProgram.Station;

namespace MineralSearchingProgram;

internal class Engine
{
	private Coordinate _result;

    private readonly SearchingStationFactory _searchingStationFactory;
	private readonly MeteorFactory _meteorFactory;

	public Engine()
	{
		_searchingStationFactory = new SearchingStationFactory();
		_meteorFactory = new MeteorFactory();

	}
    public Engine Launch()
	{
		var asteroid = _meteorFactory.Generate();
		var asteroidCoordinates = asteroid.GetCoordinates();

		var station = _searchingStationFactory.Generate();
		var distance = station.GetDistanceToMeteor(asteroidCoordinates);
		station.CalculateSurfaceCoordinates();


		return this;
	}

	public Coordinate GetResult()
	{
		return _result;
	}
}

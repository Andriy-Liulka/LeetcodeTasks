﻿using MineralSearchingProgram;

var Result = new Engine().Launch().GetResult();